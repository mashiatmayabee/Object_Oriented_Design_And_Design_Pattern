public class SMSNotification implements Notification {
    public void notifyUser(){
        System.out.println("Sending an sms notification to user.");
    }
}