public class PushNotification implements Notification {
    public void notifyUser(){
        System.out.println("Sending a push notification.");
    }
}